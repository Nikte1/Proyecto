<div style="padding: 15px; background: #d6d6eeff; border-left: 5px solid #d6d6eeff; margin-bottom: 20px;">
    <strong>Alerta:</strong> <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/components/alert.blade.php ENDPATH**/ ?>