

<?php $__env->startSection('content'); ?>
<div style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.08);">

    <h1 style="color: #6d3f6a; font-weight: 600; margin-bottom: 20px;">
        Productos
    </h1>

    <a href="<?php echo e(route('productos.create')); ?>" 
       style="background:#d97bd3; padding:10px 15px; color:white; border-radius:8px; text-decoration:none; font-weight:600;">
        <i class="fa-solid fa-plus"></i> Crear Producto
    </a>

    <table style="width:100%; margin-top:25px; border-collapse:collapse;">
        <thead>
            <tr style="background:#f5d3f1; color:#4a003f;">
                <th style="padding:12px; border-bottom:2px solid #e7b5df;">ID</th>
                <th style="padding:12px; border-bottom:2px solid #e7b5df;">Nombre</th>
                <th style="padding:12px; border-bottom:2px solid #e7b5df;">Categoría</th>
                <th style="padding:12px; border-bottom:2px solid #e7b5df;">Precio</th>
                <th style="padding:12px; border-bottom:2px solid #e7b5df;">Descripcion</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="text-align:center;">
                    <td style="padding:12px; border-bottom:1px solid #f0e1ee;"><?php echo e($producto->id); ?></td>
                    <td style="padding:12px; border-bottom:1px solid #f0e1ee;"><?php echo e($producto->nombre); ?></td>
                    <td style="padding:12px; border-bottom:1px solid #f0e1ee;"><?php echo e($producto->categoria); ?></td>
                    <td style="padding:12px; border-bottom:1px solid #f0e1ee;">$<?php echo e($producto->precio); ?></td>

                    <td style="padding:12px; border-bottom:1px solid #f0e1ee;">
                        <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" 
                           style="background:#f5d3f1; padding:6px 12px; border-radius:6px; text-decoration:none; margin-right:6px; color:#4a003f;">
                            Editar
                        </a>

                        <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" 
                              method="POST" 
                              style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button 
                                style="background:#e57373; padding:6px 12px; border:none; color:white; border-radius:6px; cursor:pointer;">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="padding:20px; color:#888;">
                        No hay productos registrados.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/productos/index.blade.php ENDPATH**/ ?>