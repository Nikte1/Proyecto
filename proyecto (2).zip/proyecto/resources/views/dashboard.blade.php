@extends('layout')

@section('content')
<h1>Dashboard</h1>

<x-alert>
    Bienvenida a la página de tareas 
</x-alert>

<x-card title="Orientación">
    Esto es una guía de ayuda para entender Laravel.
</x-card>

<x-button>Haz clic aquí</x-button>

@endsection
