@extends('layout')

@section('content')
<h1>Posts</h1>
<p>En Laravel, "post" comúnmente se refiere al manejo de solicitudes HTTP POST, que se utilizan para enviar datos al servidor, generalmente desde formularios.</p>
@endsection
