<button style="background:#4a90e2; color:white; padding:10px 18px; border:none; border-radius:6px;">
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\proyecto\resources\views/components/button.blade.php ENDPATH**/ ?>