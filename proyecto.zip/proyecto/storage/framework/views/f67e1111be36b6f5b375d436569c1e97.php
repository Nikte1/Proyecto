

<?php $__env->startSection('content'); ?>
<h1>Posts</h1>
<p>En Laravel, "post" comúnmente se refiere al manejo de solicitudes HTTP POST, que se utilizan para enviar datos al servidor, generalmente desde formularios.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\proyecto\resources\views/posts.blade.php ENDPATH**/ ?>