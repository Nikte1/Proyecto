

<?php $__env->startSection('content'); ?>
<h1>Pages</h1>
<p>En Laravel, "páginas" se refiere generalmente a las distintas vistas o contenido que se muestran a los usuarios dentro de una aplicación web. Estas páginas se crean combinando las características principales de Laravel, entre ellas:
Plantillas Blade: El motor de plantillas de Laravel, Blade, se utiliza para crear la estructura HTML y el contenido dinámico de las páginas. Blade permite crear plantillas limpias y reutilizables con características como herencia, componentes y estructuras de control.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\resources\views/pages.blade.php ENDPATH**/ ?>