@extends('layout')

@section('content')
<h1>Pages</h1>
<p>En Laravel, "páginas" se refiere generalmente a las distintas vistas o contenido que se muestran a los usuarios dentro de una aplicación web. Estas páginas se crean combinando las características principales de Laravel, entre ellas:
Plantillas Blade: El motor de plantillas de Laravel, Blade, se utiliza para crear la estructura HTML y el contenido dinámico de las páginas. Blade permite crear plantillas limpias y reutilizables con características como herencia, componentes y estructuras de control.</p>
@endsection
