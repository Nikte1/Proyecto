@extends('layout')

@section('content')
<h1>Media</h1>
<p>Contenido relacionado con archivos multimedia.</p>
@endsection
