<div style="padding: 15px; background: #d6d6eeff; border-left: 5px solid #d6d6eeff; margin-bottom: 20px;">
    <strong>Alerta:</strong> {{ $slot }}
</div>
